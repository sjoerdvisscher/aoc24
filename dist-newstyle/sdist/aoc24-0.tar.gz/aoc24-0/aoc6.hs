import Data.Array
import Data.List (find)
import Data.Maybe (fromJust)
import Data.Char (chr, ord)
import Debug.Trace (trace, traceShow)
import qualified Data.Set as S

main :: IO ()
main = interact (show . val . mkArr . lines)

mkArr :: [[Char]] -> Array (Int, Int) Char
mkArr lns' = listArray ((0, 0), (h + 2 - 1, w + 2 - 1)) (concat lns)
  where
    h = length lns'
    w = length (head lns')
    lns = [replicate (w + 2) ' '] ++ map (\l -> " " ++ l ++ " ") lns' ++ [replicate (w + 2) ' ']

val :: Array (Int, Int) Char -> Int
val arr0 = S.size (go p0 (-1, 0) S.empty (chr 300) (arr0 // [(p0, '.')]))
  where
    p0 = fst $ fromJust $ find ((== '^') . snd) (assocs arr0)
    go p@(y, x) (dy, dx) acc k arr =
      if c == ' ' then acc else
        next (dy, dx) k
      where
        c = arr ! p
        next (dy, dx) k' = let p' = (y + dy, x + dx) in
          if arr ! p' == '#'
            then next (dx, -dy) (succ k')
            else go p' (dy, dx) (acc <> if check p (dx, -dy) p (dx, -dy) 0 (arr // [(p', '#')]) == 1 then S.singleton p else S.empty) k' (arr // [(p, k)])
        check p@(y, x) d@(dy, dx) p0 d0 i arr' = let k = arr' ! p in
          if p == p0 && d == d0 && i > 0 then dbg arr 1
          else if k == ' ' then 0
          else if k == '#' then check (y - dy, x - dx) (dx, -dy) p0 d0 i arr'
          else if i == 100000 then 1
          else check (y + dy, x + dx) (dy, dx) p0 d0 (i + 1) arr'

dbg :: Array (Int, Int) Char -> a -> a
dbg arr = go (elems arr)
  where
    go [] x = x
    go s x = let (l, s') = splitAt (w + 1) s in trace l $ go s' x
    (h, w) = snd (bounds arr)